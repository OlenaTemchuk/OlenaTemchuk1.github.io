import { Component, OnInit } from '@angular/core';
import {NavigationService} from "../navigation.service";
import {select, Store} from "@ngrx/store";
import {selectCart} from "../reducers/user/user.selector";
import {UserRemoveItemFromCartAction} from "../reducers/user/user.action";
import {MatDialog} from "@angular/material/dialog";
import {DialogCheckoutComponent} from "../dialog-checkout/dialog-checkout.component";

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  public cart$ = this.store$.pipe(select(selectCart));
  constructor(public navigationService: NavigationService, private store$: Store, private dialog: MatDialog) { }

  ngOnInit(): void {
  }

  public getSum(items: any[] | null) {
    return items?.reduce((acc: any, curr) => acc + curr.price, 0)
  }

  public removeFromCart(id: string) {
    this.store$.dispatch(new UserRemoveItemFromCartAction({ item_id: id }))
  }

  openCheckout() {
    this.dialog.open(DialogCheckoutComponent, { width: '800px', height: '300px' })
  }
}
