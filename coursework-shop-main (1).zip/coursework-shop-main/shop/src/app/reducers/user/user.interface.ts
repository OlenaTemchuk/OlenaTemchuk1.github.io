export interface UserInterface {
  email: string;
  name: string,
  cart: any[],
  addresses: any[],
  purchases: any[]
}
