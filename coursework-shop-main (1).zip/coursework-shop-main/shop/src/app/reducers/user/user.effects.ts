import {Injectable} from "@angular/core";
import {Actions, createEffect, ofType, ROOT_EFFECTS_INIT} from "@ngrx/effects";
import {RequestService} from "../../request.service";
import {userActionsType} from "./user.types";
import {map, mergeMap, tap} from "rxjs/operators";
import {
  UserAddItemToCartSuccessAction,
  UserLoadAction,
  UserLoadFailAction,
  UserLoadSuccessAction,
  UserLoginSuccessAction
} from "./user.action";
import {MatSnackBar} from "@angular/material/snack-bar";
import {UserService} from "../../user.service";
import {MatDialog} from "@angular/material/dialog";
import {DialogLoginComponent} from "../../dialog-login/dialog-login.component";

@Injectable()
export class UserEffects {
  constructor(private actions$: Actions,
              private requestService: RequestService,
              private snackBar: MatSnackBar,
              private userService: UserService,
              private dialog: MatDialog) {}

  init$ = createEffect(() => this.actions$.pipe(
    ofType(ROOT_EFFECTS_INIT),
    map(() => new UserLoadAction())
  ))

  userLogin$ = createEffect(() => this.actions$.pipe(
    ofType(userActionsType.LOGIN),
    mergeMap((action: { payload: { email: string, password: string } }) => {
      return this.requestService.post('/api/user/login', { email: action.payload.email, password: action.payload.password }).then(res => {
        if (res.success) {
          return new UserLoginSuccessAction(res.profile);
        } else {
          return new UserLoadFailAction()
        }
      })
    })
  ))

  userRegister$ = createEffect(() => this.actions$.pipe(
    ofType(userActionsType.REGISTER),
    mergeMap((action: { payload: { name: string, email: string, password: string } }) => {
      return this.requestService.post('/api/user/register', {
        name: action.payload.email, email: action.payload.email, password: action.payload.password
      }).then(res => {
        if (res.success) {
          return new UserLoginSuccessAction(res.profile);
        } else {
          return new UserLoadFailAction()
        }
      })
    })
  ))

  userLoginSuccess$ = createEffect(() => this.actions$.pipe(
    ofType(userActionsType.LOGIN_SUCCESS),
    map((action: { payload: { email: string }}) => {
      this.snackBar.open('Login success', '', {
        verticalPosition: 'bottom',
        horizontalPosition: 'right',
        duration: 5000
      })
      this.userService.login(action.payload.email)
    })
  ), { dispatch: false })

  loadInformation$ = createEffect(() => this.actions$.pipe(
      ofType(userActionsType.LOAD),
      mergeMap(() => {
          return this.requestService.get('/api/user/').then(res => {
            if (res.success) {
              return new UserLoadSuccessAction(res.profile);
            } else {
              return new UserLoadFailAction();
            }
          })
      })
  ))

  loadInformationFail$ = createEffect(() => this.actions$.pipe(
    ofType(userActionsType.LOAD_FAIL),
    tap(() => {
      this.userService.logOut();
      this.dialog.open(DialogLoginComponent, {
        width: '450px',
        height: '500px'
      })
      this.snackBar.open('To access the cart and stories - log in', '', {
        verticalPosition: 'bottom',
        horizontalPosition: 'right',
        duration: 5000
      })
    })
  ), { dispatch: false })

  addItemToCart$ = createEffect(() => this.actions$.pipe(
    ofType(userActionsType.ADD_TO_CART),
    mergeMap((actions: { payload: { item_id: string } }) => {
      return this.requestService.post('/api/user/addToCart', { itemID: actions.payload.item_id }).then(res => {
        if (res.success) {
          this.snackBar.open('Item added to cart successfully', '', {
            verticalPosition: 'bottom',
            horizontalPosition: 'right',
            duration: 10000
          })
          return new UserAddItemToCartSuccessAction({ cart: res.cart});
        } else {
          return new UserLoadFailAction();
        }
      })
    })
  ))

  removeItemFromCart$ = createEffect(() => this.actions$.pipe(
    ofType(userActionsType.REMOVE_FROM_CART),
    mergeMap((actions: { payload: { item_id: string } }) => {
      return this.requestService.post('/api/user/removeItemFromCart', { itemID: actions.payload.item_id }).then(res => {
        if (res.success) {
          this.snackBar.open('Item removed successfully', '', {
            verticalPosition: 'bottom',
            horizontalPosition: 'right',
            duration: 10000
          })
          return new UserAddItemToCartSuccessAction({ cart: res.cart});
        } else {
          return new UserLoadFailAction();
        }
      })
    })
  ))
}
