import { Action } from "@ngrx/store";
import {userActionsType} from "./user.types";

export class UserLoadAction implements Action {
  readonly type = userActionsType.LOAD;
  constructor() {}
}

export class UserLoadSuccessAction implements Action {
  readonly type = userActionsType.LOAD_SUCCESS;
  constructor(public payload: { user: any }) {}
}

export class UserLoadFailAction implements Action {
  readonly type = userActionsType.LOAD_FAIL;
}

export class UserLoginAction implements Action {
  readonly type = userActionsType.LOGIN;
  constructor(public payload: { email: string, password: string }) {}
}

export class UserRegisterAction implements Action {
  readonly type = userActionsType.REGISTER;
  constructor(public payload: { name: string, email: string, password: string }) {}
}

export class UserLoginSuccessAction implements Action {
  readonly type = userActionsType.LOGIN_SUCCESS;
  constructor(public payload: { profile: any }) {}
}

export class UserAddItemToCartAction implements Action {
  readonly type = userActionsType.ADD_TO_CART;
  constructor(public payload: { item_id: string }) {}
}

export class UserRemoveItemFromCartAction implements Action {
  readonly type = userActionsType.REMOVE_FROM_CART;
  constructor(public payload: { item_id: string }) {}
}

export class UserAddItemToCartSuccessAction implements Action {
  readonly type = userActionsType.ADD_TO_CART_SUCCESS;
  constructor(public payload: { cart: any[] }) {}
}


export type UsersActions = UserLoadAction |
  UserLoadSuccessAction |
  UserLoginAction |
  UserLoginSuccessAction |
  UserAddItemToCartAction |
  UserAddItemToCartSuccessAction |
  UserRemoveItemFromCartAction |
  UserRegisterAction
