import { createFeatureSelector, createSelector } from "@ngrx/store";
import { UserInterface } from "./user.interface";

export const selectUserFeature = createFeatureSelector<UserInterface>('user');

export const selectUser = createSelector(
  selectUserFeature,
  (state: UserInterface) => state
)

export const selectCart = createSelector(
  selectUserFeature,
  (state: UserInterface) => state.cart
)

export const selectOrders = createSelector(
  selectUserFeature,
  (state: UserInterface) => state.purchases
)
