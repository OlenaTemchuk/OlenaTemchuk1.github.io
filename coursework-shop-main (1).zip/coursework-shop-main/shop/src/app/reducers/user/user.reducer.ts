import {UsersActions} from "./user.action";
import {userActionsType} from "./user.types";
import {UserInterface} from "./user.interface";

const initialState: UserInterface = {
  email: '',
  name: '',
  cart: [],
  addresses: [],
  purchases: []
}

export const userReducer = (state = initialState, actions: UsersActions) => {
  switch (actions.type) {
    case userActionsType.LOGIN_SUCCESS: {
      return {
        ...state,
        ...actions.payload
      }
    }
    case userActionsType.LOAD_SUCCESS: {
      return {
        ...state,
        ...actions.payload
      }
    }
    case userActionsType.ADD_TO_CART_SUCCESS: {
      return {
        ...state,
        cart: actions.payload.cart
      }
    }
    default: return state
  }
}
