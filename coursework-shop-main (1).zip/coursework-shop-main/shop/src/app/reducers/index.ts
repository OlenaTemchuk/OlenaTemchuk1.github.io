import {
  ActionReducerMap, MetaReducer
} from "@ngrx/store";
import { UserInterface } from "./user/user.interface";
import { userReducer } from "./user/user.reducer";

export interface State {
  user: UserInterface
}

export const reducers: ActionReducerMap<State> = {
  //@ts-ignore
  "user": userReducer
}

export const metaReducers: MetaReducer<State>[] = [];
