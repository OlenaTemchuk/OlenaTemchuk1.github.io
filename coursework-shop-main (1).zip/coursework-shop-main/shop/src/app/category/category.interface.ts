export interface CategoryInterface {
  id: string;
  name: string;
  photo: string;
  price: number;
  short_description: string;
  description: string;
  count: number;
  category: string;
  seller: string;
  country: string;
  size: string;
}
