import { Component, OnInit } from '@angular/core';
import {NavigationService} from "../navigation.service";
import {RequestService} from "../request.service";
import {ActivatedRoute} from "@angular/router";
import {CategoryInterface} from "./category.interface";
import {Store} from "@ngrx/store";
import {UserAddItemToCartAction} from "../reducers/user/user.action";

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  public filters: { sellers: { name: string, checked: boolean }[], country: { name: string, checked: boolean }[] } = {
    sellers: [],
    country: []
  };

  public productsAll: CategoryInterface[] = [];
  public products: CategoryInterface[] = [];

  public searchValue: string = "";
  public categoryName: string = '';
  constructor(public navigationService: NavigationService,
              private requestService: RequestService,
              private route: ActivatedRoute,
              private store$: Store) { }

  ngOnInit(): void {
    this.loadProducts().then();
  }

  async loadProducts() {
    const category = this.route.snapshot.paramMap.get('id');

    this.categoryName = category || '';

    const response = await this.requestService.get(`/api/products/category/${category}`);

    if (response.success) this.products = this.productsAll = response.items;
    this.createFilters();
  }

  createFilters() {
    let sellers: string[] = [],
      countries: string[] = [];

    this.products.forEach(product => {
      sellers.push(product.seller)
      countries.push(product.country)
    })

    this.filters.sellers = [...new Set(sellers)].map(seller => ({ name: seller, checked: false }));
    this.filters.country = [...new Set(countries)].map(country => ({ name: country, checked: false }));
    // this.products.forEach()
  }

  selectFilter() {
    const countryFilterValue: string[] = this.filters.country.filter(country => country.checked).map(country => country.name);
    const sellersFilterValue: string[] = this.filters.sellers.filter(seller => seller.checked).map(seller => seller.name);

    this.products = this.productsAll.filter(product => {
      return (
        (countryFilterValue.length === 0 || countryFilterValue.includes(product.country)) &&
        (sellersFilterValue.length === 0 || sellersFilterValue.includes(product.seller))
      );
    })
  }

  resetFilters() {
    this.filters.sellers = [];
    this.filters.country = [];

    this.products = [...this.productsAll];
    this.createFilters()
  }

  addToCart(itemID: string) {
    this.store$.dispatch(new UserAddItemToCartAction({ item_id: itemID }))
  }

  cutString(str: string, length = 45) {
    return str.length > length ? str.substring(0, length) + '...' : str;
  }
}
