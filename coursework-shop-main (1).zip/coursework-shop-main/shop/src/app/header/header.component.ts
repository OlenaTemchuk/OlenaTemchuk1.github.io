import { Component, OnInit } from '@angular/core';
import {UserService} from "../user.service";
import {select, Store} from "@ngrx/store";
import {selectCart} from "../reducers/user/user.selector";
import {MatDialog} from "@angular/material/dialog";
import {DialogAddItemComponent} from "../dialog-add-item/dialog-add-item.component";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  public cart$ = this.store$.pipe(select(selectCart))
  constructor(public userService: UserService, private store$: Store, private dialog: MatDialog) { }

  ngOnInit(): void {}

  public addItem() {
    this.dialog.open(DialogAddItemComponent, { width: '450px', height: '550px' })
  }

}
