import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './header/header.component';
import {MatIconModule} from "@angular/material/icon";
import {MatToolbarModule} from "@angular/material/toolbar";
import {MatButtonModule} from "@angular/material/button";
import { HomeComponent } from './home/home.component';
import { CategoryComponent } from './category/category.component';
import {MatSidenavModule} from "@angular/material/sidenav";
import {MatCheckboxModule} from "@angular/material/checkbox";
import {MatInputModule} from "@angular/material/input";
import {MatCardModule} from "@angular/material/card";
import { ProductComponent } from './product/product.component';
import {MatTabsModule} from "@angular/material/tabs";
import { CartComponent } from './cart/cart.component';
import {MatMenuModule} from "@angular/material/menu";
import { DialogLoginComponent } from './dialog-login/dialog-login.component';
import {MatDialogModule} from "@angular/material/dialog";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from '../environments/environment';
import { EffectsModule } from '@ngrx/effects';
import {metaReducers, reducers} from "./reducers";
import {MatSnackBarModule} from "@angular/material/snack-bar";
import {UserEffects} from "./reducers/user/user.effects";
import {HttpClientModule} from "@angular/common/http";
import {MatBadgeModule} from "@angular/material/badge";
import { DialogAddItemComponent } from './dialog-add-item/dialog-add-item.component';
import {MatStepperModule} from "@angular/material/stepper";
import { DialogCheckoutComponent } from './dialog-checkout/dialog-checkout.component';
import { OrdersComponent } from './orders/orders.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    CategoryComponent,
    ProductComponent,
    CartComponent,
    DialogLoginComponent,
    DialogAddItemComponent,
    DialogCheckoutComponent,
    OrdersComponent
  ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        MatIconModule,
        MatToolbarModule,
        MatButtonModule,
        MatSidenavModule,
        MatCheckboxModule,
        MatInputModule,
        MatCardModule,
        MatTabsModule,
        MatMenuModule,
        MatDialogModule,
        MatSnackBarModule,
        HttpClientModule,
        ReactiveFormsModule,
        StoreModule.forRoot(reducers, {
            metaReducers,
            runtimeChecks: {
                strictStateImmutability: true,
                strictActionImmutability: true
            }
        }),
        StoreDevtoolsModule.instrument({maxAge: 25, logOnly: environment.production}),
        EffectsModule.forRoot([UserEffects]),
        FormsModule,
        MatBadgeModule,
        MatStepperModule
    ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
