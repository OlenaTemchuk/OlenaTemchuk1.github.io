import { Component } from '@angular/core';
import {MatDialog} from "@angular/material/dialog";
import {DialogLoginComponent} from "./dialog-login/dialog-login.component";
import {UserService} from "./user.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'shop';

  constructor(private userService: UserService) {}
}
