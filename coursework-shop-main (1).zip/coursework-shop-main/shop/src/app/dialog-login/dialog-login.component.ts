import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from "@angular/forms";
import {Store} from "@ngrx/store";
import {UserLoginAction, UserRegisterAction} from "../reducers/user/user.action";
import {MatDialogRef} from "@angular/material/dialog";

@Component({
  selector: 'app-dialog-login',
  templateUrl: './dialog-login.component.html',
  styleUrls: ['./dialog-login.component.css']
})
export class DialogLoginComponent implements OnInit {
  email = new FormControl('', [Validators.required, Validators.email]);
  password = new FormControl('', [Validators.required, Validators.minLength(8)]);
  name = new FormControl('', [Validators.required]);
  hidePassword = true;
  typeDialogue: 'Login' | 'Registration' = "Login"

  constructor(private store$: Store, private dialogRef: MatDialogRef<DialogLoginComponent>) { }

  ngOnInit(): void {
  }

  getErrorMessageEmail() {
    if (this.email.hasError('required')) {
      return 'You must enter a value';
    }

    return this.email.hasError('email') ? 'Not a valid email' : '';
  }

  getErrorMessagePassword() {
    if (this.password.hasError('required')) {
      return 'You must enter a value';
    }

    return this.password.hasError('min') ? 'Not a valid password. Length must be between 8 and 24 characters.' : '';
  }

  login() {
    const email = this.email.valid && this.email.value;
    const password = this.password.valid && this.password.value;

    if (!email || !password) {
      this.email.markAllAsTouched()
      this.password.markAllAsTouched()
      return
    }

    this.store$.dispatch(new UserLoginAction({ email, password }))
    this.dialogRef.close();
  }

  register() {
    const name = this.name.valid && this.name.value;
    const email = this.email.valid && this.email.value;
    const password = this.password.valid && this.password.value;

    if (!name || !email || !password) {
      this.email.markAllAsTouched()
      this.password.markAllAsTouched()
      return
    }

    this.store$.dispatch(new UserRegisterAction({ name, email, password }))
    this.dialogRef.close();
  }

}
