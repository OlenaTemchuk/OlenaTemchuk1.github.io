import { Injectable } from '@angular/core';
import {DialogLoginComponent} from "./dialog-login/dialog-login.component";
import {MatDialog} from "@angular/material/dialog";

@Injectable({
  providedIn: 'root'
})
export class UserService {
  public currentUser? = localStorage.getItem('user');

  constructor(private dialog: MatDialog) { }

  public logOut() {
    this.currentUser = null;
    localStorage.removeItem('user');
  }

  public isLogged() {
    return !!this.currentUser
  }

  public login(email: string) {
    this.currentUser = email;
    localStorage.setItem('user', email);
  }

  public loginDialog() {
    this.dialog.open(DialogLoginComponent, {
      width: '450px',
      height: '500px'
    })
  }
}
