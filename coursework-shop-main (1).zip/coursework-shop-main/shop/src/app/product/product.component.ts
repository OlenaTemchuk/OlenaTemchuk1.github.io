import { Component, OnInit } from '@angular/core';
import {NavigationService} from "../navigation.service";
import {CategoryInterface} from "../category/category.interface";
import {RequestService} from "../request.service";
import {ActivatedRoute} from "@angular/router";
import {UserAddItemToCartAction} from "../reducers/user/user.action";
import {Store} from "@ngrx/store";
import {UserService} from "../user.service";

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  public product?: CategoryInterface;

  constructor(public navigationService: NavigationService,
              public userService: UserService,
              private requestService: RequestService,
              private route: ActivatedRoute,
              private store$: Store) { }

  ngOnInit(): void {
    this.loadProductInfo()
  }

  async loadProductInfo() {
    const id = this.route.snapshot.paramMap.get('id');
    const response = await this.requestService.get(`/api/products/${id}`)

    if (response.success) this.product = response.information;
  }

  addToCart(itemID?: string) {
    if (itemID) this.store$.dispatch(new UserAddItemToCartAction({ item_id: itemID }))
  }

  async deleteProduct(id?: string) {
    if (id) await this.requestService.post('/api/products/delete', { id: id })
    this.navigationService.goBack();
  }

}
