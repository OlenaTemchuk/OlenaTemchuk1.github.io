import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from "@angular/forms";
import {RequestService} from "../request.service";
import {MatDialogRef} from "@angular/material/dialog";
import {MatSnackBar} from "@angular/material/snack-bar";

@Component({
  selector: 'app-dialog-add-item',
  templateUrl: './dialog-add-item.component.html',
  styleUrls: ['./dialog-add-item.component.css']
})
export class DialogAddItemComponent implements OnInit {
  item_name = new FormControl('', [Validators.required]);
  item_photo = new FormControl('', [Validators.required]);
  item_price = new FormControl('', [Validators.required]);
  item_short_description = new FormControl('', [Validators.required]);
  item_description = new FormControl('', [Validators.required]);
  item_count = new FormControl('', [Validators.required]);
  item_category = new FormControl('', [Validators.required]);
  item_seller = new FormControl('', [Validators.required]);
  item_country = new FormControl('', [Validators.required]);
  item_size = new FormControl('', [Validators.required]);

  constructor(private requestService: RequestService,
              private dialogRef: MatDialogRef<DialogAddItemComponent>,
              private snackBar: MatSnackBar) { }

  ngOnInit(): void {
  }


  async addItem() {
    const name = this.item_name.valid && this.item_name.value;
    const photo = this.item_photo.valid && this.item_photo.value;
    const price = this.item_price.valid && this.item_price.value;
    const short_description = this.item_short_description.valid && this.item_short_description.value;
    const description = this.item_description.valid && this.item_description.value;
    const count = this.item_count.valid && this.item_count.value;
    const category = this.item_category.valid && this.item_category.value;
    const seller = this.item_seller.valid && this.item_seller.value;
    const country  = this.item_country.valid && this.item_country.value;
    const size  = this.item_size.valid && this.item_size.value;

    if (!name || !photo || !price || !short_description || !description || !count || !category || !seller || !country || !size) {
      this.item_name.markAllAsTouched()
      this.item_photo.markAllAsTouched()
      this.item_price.markAllAsTouched()
      this.item_short_description.markAllAsTouched()
      this.item_description.markAllAsTouched()
      this.item_count.markAllAsTouched()
      this.item_category.markAllAsTouched()
      this.item_seller.markAllAsTouched()
      this.item_country.markAllAsTouched()
      this.item_size.markAllAsTouched()
      return
    }

    const result = await this.requestService.post('/api/products', {
      name, photo, price, short_description, description, count, category, seller, country, size
    })

    this.snackBar.open(
      (result.success ? 'Товар добавлений, обнови сторінку, щоб побачити його' : 'Товар не добавлений, перевірь правильність даних'), '', {
      horizontalPosition: 'end',
      verticalPosition: 'bottom',
      duration: 10000
    })

    result.success && this.dialogRef.close();
  }
}
