import { Component, OnInit } from '@angular/core';
import {select, Store} from "@ngrx/store";
import {selectCart, selectOrders} from "../reducers/user/user.selector";
import {NavigationService} from "../navigation.service";

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  public orders$ = this.store$.pipe(select(selectOrders));
  constructor(private store$: Store, public navigationService: NavigationService) { }

  ngOnInit(): void {
  }

}
