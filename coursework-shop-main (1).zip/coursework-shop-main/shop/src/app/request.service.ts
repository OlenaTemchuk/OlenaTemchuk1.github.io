import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {UserService} from "./user.service";

export const API_URL = '';

@Injectable({
  providedIn: 'root'
})
export class RequestService {

  constructor(private http: HttpClient, private userService: UserService) { }

  public async get(url: string): Promise<any> {
    return new Promise(resolve => {
      console.log('wtf')
      const response = this.http.get<any>(API_URL + url, { headers: { Authorization: this.userService.currentUser ?? 'unknow'} })
        .subscribe(res => {
          console.log('aaa', res)
          if (res.success === true) {
            resolve(res);
          } else {
            console.error(res, false)
            resolve(res);
          }
          response.unsubscribe()
        }, error => {
          resolve({success: false})
        })
    })
  }

  public async post(url: string, params?: any): Promise<any> {
    return new Promise(resolve => {
      const response = this.http.post<any>(API_URL + url, params, { headers: { Authorization: this.userService.currentUser ?? 'unknow' } })
        .subscribe(res => {
          if (res.success) {
            resolve(res);
          } else {
            console.error(res)
            resolve(res);
          }

          response.unsubscribe();
        }, error => {
          resolve({success: false})
        })
    })
  }

  public async put(url: string, params?: any): Promise<any> {
    return new Promise(resolve => {
      const response = this.http.put<any>(API_URL + url, params, { headers: { Authorization: this.userService.currentUser ?? 'unknow' } })
        .subscribe(res => {
          if (res.success) {
            resolve(res);
          } else {
            console.error(res)
            resolve(res);
          }

          response.unsubscribe();
        }, error => {
          resolve({success: false})
        })
    })
  }

  public async delete(url: string): Promise<any> {
    return new Promise(resolve => {
      const response = this.http.delete<any>(API_URL + url, { headers: { Authorization: this.userService.currentUser ?? 'unknow' } })
        .subscribe(res => {
          if (res.success) {
            resolve(res);
          } else {
            console.error(res)
            resolve(res);
          }

          response.unsubscribe()
        }, error => {
          resolve({success: false})
        })
    })
  }
}
