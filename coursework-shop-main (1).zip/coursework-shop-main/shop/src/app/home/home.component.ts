import { Component, OnInit } from '@angular/core';
import {RequestService} from "../request.service";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public categories = []
  constructor(private requestService: RequestService) { }

  ngOnInit(): void {
    this.loadCategories().then();
  }

  async loadCategories() {
    const response = await this.requestService.get('/api/products/category');
    if (response.success) this.categories = response.categories;
  }

}
