import { Component, OnInit } from '@angular/core';
import {RequestService} from "../request.service";
import {Store} from "@ngrx/store";
import {UserLoadAction} from "../reducers/user/user.action";

@Component({
  selector: 'app-dialog-checkout',
  templateUrl: './dialog-checkout.component.html',
  styleUrls: ['./dialog-checkout.component.css']
})
export class DialogCheckoutComponent implements OnInit {
  constructor(private requestService: RequestService, private store$: Store) { }

  ngOnInit(): void {}

  order() {
    this.requestService.post('/api/user/order').then(() => this.store$.dispatch(new UserLoadAction()))
  }

}
