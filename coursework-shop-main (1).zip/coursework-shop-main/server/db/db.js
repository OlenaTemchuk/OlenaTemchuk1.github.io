const fs = require('fs')
const path = require('path')

// config
const {mongoURI} = require('../config')

// mongo
const mongoose = require('mongoose');

// connect to MongoDB
const mongoConnect = async () => {
    return new Promise((resolve, reject) => {
        mongoose.connect(mongoURI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            autoIndex: false,
            keepAlive: true
        }).then(() => {
                console.log('MongoDB connected')
                resolve(true)
            })
            .catch(e => {
                reject(e)
            })

        // mongoDB.once('open', () => console.log('connected to the database'));
    })
}

module.exports = {
    mongoConnect
}