const express = require('express')
const router = express.Router()

const AuthMiddleware = require('../common/auth.middleware')
const productsController = require('./products.controller')

router.get('/category', productsController.getCategories)
router.get('/category/:id', productsController.loadCategory)
router.get('/', productsController.load)
router.get('/:id', productsController.information)
router.post('/', AuthMiddleware.check, productsController.add)
router.post('/delete', AuthMiddleware.check, productsController.remove)

module.exports = router;