const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProductsSchema = new Schema({
    id: { type: String, unique: true, index: true },
    name: { type: String, required: true},
    photo: { type: String, required: true},
    price: { type: Number, required: true},
    short_description: { type: String, required: true},
    description: { type: String, required: true},
    count: { type: Number, required: true},
    category: { type: String, required: true},
    seller: { type: String, required: true},
    country: { type: String, required: true},
    size: { type: String, required: true}
})

module.exports = mongoose.model('products', ProductsSchema)