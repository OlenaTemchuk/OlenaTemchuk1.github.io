const productsService = require('./products.service')

class ProductsController {
    load = async (req, res) => {

    }

    loadCategory = async (req, res) => {
        const categoryID = req.params.id;

        const items = await productsService.getItemsFromCategory(categoryID);

        return res.json({
            success: true,
            items
        })
    }

    getCategories = async (req, res) => {
        const categories = await productsService.getCategories();

        return res.json({
            success: true,
            categories
        })
    }

    information = async (req, res) => {
        const productID = req.params.id;

        const [success, information] = await productsService.getInformationAboutProduct(productID);

        return res.json({
            success, information
        })
    }

    add = async (req, res) => {
        const success = await productsService.add(req.body)
        return res.json({success});
    }

    remove = async (req, res) => {
        const success = await productsService.delete(req.body.id)
        return res.json({success});
    }
}

module.exports = new ProductsController();