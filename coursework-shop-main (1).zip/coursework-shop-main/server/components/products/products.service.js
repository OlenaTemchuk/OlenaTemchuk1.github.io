const ProductsSchema = require('./products.schema')

class ProductsService {
    add = async (item) => {
        const product = new ProductsSchema({
            ...item,
            id: this.generateID()
        })

        try {
            await product.save()
            return true;
        } catch (e) {
            return false
        }

    }

    delete = async (id) => {
        try {
            await ProductsSchema.deleteOne({ id: id}).lean()
            return true;
        } catch (e) {
            return false
        }

    }

    getCategories = async () => {
        const [categories] = await Promise.all([ProductsSchema.find({}, { category: 1, _id: 0 }).lean()])

        return [...new Set(categories.map(item => item.category))]
    }

    getItemsFromCategory = async (categoryName) => {
        const [items] = await Promise.all([ProductsSchema.find({category: categoryName}, { _id: 0, __v: 0 }).lean()])

        return items
    }

    getInformationAboutProduct = async (id) => {
        const [item] = await Promise.all([ProductsSchema.findOne({id: id}, { _id: 0, __v: 0 }).lean()])

        return [!!item, item]
    }

    generateID = () => {
        return (Math.random() + 1).toString(36).substring(7);
    }
}

module.exports = new ProductsService();