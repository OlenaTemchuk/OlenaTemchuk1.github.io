const userService = require('../user/user.service')

class AuthMiddleware {
    async check(req, res, next) {
        req.user = req.headers.authorization;

        if (!req.user || req.user === 'unknow') {
            return res.status(401).json({
                success: false,
                error: "user not specified"
            })
        } else {
            const [success, candidate] = await userService.getInformation(req.user);

            if (success) return next();
            else return res.status(401).json({
                success: false
            })
        }
    }
}

module.exports = new AuthMiddleware();