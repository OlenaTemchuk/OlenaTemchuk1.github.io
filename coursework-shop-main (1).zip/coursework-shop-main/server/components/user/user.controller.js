const userService = require('./user.service')

class UserController {
    login = async (req, res) => {
        const [email, password] = [req.body.email, req.body.password];

        const [success, profile] = await userService.login(email, password)

        res.status(success ? 200 : 403).json({
            success, profile
        })
    }

    register = async (req, res) => {
        const user = {
            email: req.body.email,
            password: req.body.password,
            name: req.body.name,
        }

        if (!user.email || !user.password || !user.name) return res.status(403).json({ success: false });

        const [success, profile] = await userService.register(user)

        res.status(success ? 200 : 403).json({
            success, profile
        })
    }

    information = async (req, res) => {
        const email = req.user;
        const [success, profile] = await userService.getInformation(email)

        res.status(success ? 200 : 403).json({
            success, profile
        })
    }

    addItemToCart = async (req, res) => {
        const itemID = req.body.itemID;

        const [success, user] = await userService.addItemToCart(req.user, itemID);

        return res.json({
            success, user
        })
    }

    order = async (req, res) => {
        const user = req.user;

        const [success, orders] = await userService.order(user);

        return res.json({
            success, orders
        })
    }

    removeItemFromCart = async (req, res) => {
        const user = req.user;
        const itemID = req.body.itemID;

        const [success, cart] = await userService.removeItemFromCart(user, itemID);

        return res.json({
            success, cart
        })
    }
}

module.exports = new UserController();