const express = require('express')
const router = express.Router()

const AuthMiddleware = require('../common/auth.middleware')
const userController = require('./user.controller')

router.post('/login', userController.login)
router.post('/register', userController.register)
router.post('/addToCart', AuthMiddleware.check, userController.addItemToCart)
router.post('/order', AuthMiddleware.check, userController.order)
router.post('/removeItemFromCart', AuthMiddleware.check, userController.removeItemFromCart)
router.get('/', AuthMiddleware.check, userController.information)

module.exports = router;