const UsersSchema = require('./user.schema')
const UserDTO = require('./user.dto')

const productsService = require('../products/products.service')

class UserService {
    login = async (email, password) => {
        const candidate = await UsersSchema.findOne({email: email}).lean();

        if (!candidate) return [false, null];

        if (candidate.password !== password) return [false, null];
        else return [true, new UserDTO(candidate)]
    }

    register = async (user) => {
        try {
            const createdUser = new UsersSchema(user);
            await createdUser.save();
            return [true, new UserDTO(createdUser)];
        } catch (e) {
            return [false, null]
        }
    }

    getInformation = async (email) => {
        try {
            const candidate = await UsersSchema.findOne({email: email}, {password: 0}).lean();
            return [true, new UserDTO(candidate)];
        } catch (e) {
            return [false, null]
        }
    }

    addItemToCart = async (email, itemID) => {
        const item = await productsService.getInformationAboutProduct(itemID);

        if (item[0]) {
            item[1] = {...item[1], id_: this.generateRandomID()}
            await UsersSchema.updateOne({email: email}, {$push: {cart: item[1]}}).lean();
            const user = await this.getInformation(email);
            return [true, user[1].cart]
        } else return [false, null];
    }

    order = async (email) => {
        const candidate = await UsersSchema.findOne({email: email}, {password: 0}).lean();
        if (!candidate) return [false, null];

        await UsersSchema.updateOne({ email: email }, { cart: [], purchases: candidate.cart })

        const user = await this.getInformation(email);
        return [true, user]
    }

    removeItemFromCart = async (email, itemID) => {
        await UsersSchema.updateOne({email: email}, {$pull: {cart: {id_: itemID}}}).lean();
        const user = await this.getInformation(email);
        return [true, user[1].cart]
    }

    generateRandomID = () => (Math.random() + 1).toString(36).substring(7);
}


module.exports = new UserService();