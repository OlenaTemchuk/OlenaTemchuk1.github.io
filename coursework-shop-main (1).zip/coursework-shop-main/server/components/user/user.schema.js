const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const UsersSchema = new Schema({
    email: { type: String, unique: true, index: true },
    password: { type: String, required: true },
    name: { type: String, required: true },
    cart: { type: Array, required: false, default: [] },
    addresses: { type: Array, default: [], required: false },
    purchases: { type: Array, default: [], required: false }
})

module.exports = mongoose.model('users', UsersSchema)