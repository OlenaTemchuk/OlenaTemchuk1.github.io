class UserDto {
    constructor(user = null) {
        if (user === null) throw Error('Bad data in user DTO')
        this.email = user.email;
        this.name = user.name;
        this.cart = user.cart;
        this.addresses = user.addresses;
        this.purchases = user.purchases;
    }

}

module.exports = UserDto;