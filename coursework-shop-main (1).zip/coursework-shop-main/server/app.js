const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const cors = require('cors')

const app = express();

app.use(logger('dev'));
app.use(express.json(true))
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('x-powered-by', 'SHOPServer');

    next();
});

app.disable('etag');

// app.use(express.static(path.join(__dirname, '../ListAlpha-beta/dist')))
app.use(express.static(path.join(__dirname, './dist')))

app.use(cors({origin:true,credentials: true}))

// routes
app.use('/api/user', require('./components/user/user.routes'));
app.use('/api/products', require('./components/products/products.routes'));
app.use('*', (req, res) => res.sendFile(path.join(__dirname, './dist/index.html')));
// app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
// app.use('/api', require('./components/api/api.routes'));
// app.use('/test', require('./components/test/test.routes'));
// app.use('/share', require('./components/share/share.routes'));
// app.use('/', require('./components/mainPage/mainPage.routes'));


// catch 404 and forward to error handler
app.use(function(req, res, next) {
    next(createError(404));
});

// error handler
app.use(function(err, req, res) {
    return res.json({
        success: false,
        error: err
    })
});

module.exports = app;