module.exports = {
    mongoURI: 'mongodb+srv://server:HVDGW8Q5bGibIdhX@cluster0.z8yfu.mongodb.net/shop?retryWrites=true&w=majority'
}